const templateEje = {
    1: `
        <div id="containerEje1">
            <form id="formEje1" name="formEje1" >
                <h1>Ejercicio 1</h1>
                <div style="display: flex; flex-direction: column; width: min-content;">
                    <label for="nota1">Nota1</label>
                    <input type="number" id="nota1" name="nota1" required>
                    <label for="nota2">Nota2</label>
                    <input type="number" id="nota2" name="nota2" required>
                    <label for="nota3">Nota3</label>
                    <input type="number" id="nota3" name="nota3" required>
                    <input type="submit" id="calcular" onclick="calcular1(event)" value="Calcular">
                </div>
            </form>
            <div ><p id="resEje1"></p></div>
        </div>
        `,
    2: `
        <div id="containerEje2">
            <form id="formEje2" name="formEje2" >
                <h1>Ejercicio 2</h1>
                <div style="display: flex; flex-direction: column; width: min-content;">
                    <label for="num1">Numero</label>
                    <input type="number" id="num1" name="num1" required>
                    <input type="submit" id="calcular" onclick="calcular2(event)" value="Calcular">
                </div>
            </form>
            <div ><p id="resEje"></p></div>
        </div>
    `

}
function insertTemplate(numTemplate) {
    document.getElementById('exercises-container').innerHTML = templateEje[numTemplate];
}
function calcular1(e) {
    e.preventDefault();
    let notaProm = 0;
    for (let element of document.formEje1.elements) {
        if (element.type == "submit") continue;
        notaProm += parseFloat(element.value);
    }
    notaProm = notaProm / 3;
    document.getElementById('resEje').innerHTML = (notaProm <= 3.9 ) ? "Estudie" : "Becado";
}
function calcular2(e){
    e.preventDefault();
    const value = document.getElementById("num1").value;
    let str = (value % 2 == 0) ? "Es par" : "Es impar";
    str += (value > 10) ? " y es mayor de 10" : " y es menor o igual a 10";
    document.getElementById('resEje').innerHTML = str;
}
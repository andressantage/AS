console.log("Taller 1");
// ----------------------------------------------------------------------------------
// PUNTO 1
console.group("Punto 1");
(()=>{
    let continente = 430000000, pais = 50670000, departamento = 2200000, ciudad = 543000, barrio = 15000, direccion = 3;
    console.log(`Continente: ${continente}, Pais: ${pais}, Departamento: ${departamento}, Ciudad: ${ciudad}, Barrio: ${barrio}, Direccion: ${direccion}`)
})();
console.groupEnd();
// ----------------------------------------------------------------------------------
// PUNTO 2
console.group("Punto 2");
(()=> {
    let continente = 430000000, pais = 50670000, departamento = 2200000, ciudad = 543000, barrio = 15000, direccion = 3;
    let  idioma, esTercerMundista = true;
    console.log(`esTercerMundista: ${esTercerMundista}, continente: ${continente}, pais: ${pais}, idioma: ${idioma}`)
})();
console.groupEnd();
// ----------------------------------------------------------------------------------
// PUNTO 3
console.group("Punto 3");
(()=>{
    let continente = 430000000, pais = 50670000, departamento = 2200000, ciudad = 543000, barrio = 15000, direccion = 3;
    const esTercerMundista = true, idioma = 'Español';
    console.log(`esTercerMundista: ${esTercerMundista}, continente: ${continente}, pais: ${pais}, idioma: ${idioma}`)
})()
console.groupEnd();
// ----------------------------------------------------------------------------------
// PUNTO 4
console.group("Punto 4");
(()=>{
    /* a) Si su país se dividiera por la mitad, y cada mitad contendría la
    mitad de la población, Entonces, ¿cuántas personas vivirían en cada
    mitad? */
    let pais = 50670000;
    let mitad = pais/2;
    console.log(`La cantidad de personas que vivirian en cada mitad son: ${mitad}`)
    /* b) Aumente la población de su país en 1M y registre el resultado
    en la consola */
    let paisAumentado = pais + 1000000;
    console.log(`La poblacion aumentada es: ${paisAumentado}`)
    /* c) Finlandia tiene una población de 6 millones. ¿Tu país tiene más
    gente que ¿Finlandia? */
    let finlandia = 6000000;
    (pais > finlandia) ? console.log(`Tu pais tiene mas gente que Finlandia`) : console.log(`Tu pais tiene menos gente que Finlandia`)
    /* d) La población promedio de un país es de 33 millones de
    personas. ¿Tu país tiene menos gente que el país promedio? */
    let promedio = 33000000;
    (pais < promedio) ? console.log(`Tu pais tiene menos gente que el pais promedio`) : console.log(`Tu pais tiene mas gente que el pais promedio`)
    /* Basado en las variables que creó, cree una nueva variable
    'descripción' que contiene una cadena con este formato: 'Colombia
    está en América, y Bucaramanga que está en el departamento de
    Santander tiene un barrio llamado el prado y sus 3000 personas
    hablan inglés */
    let descripcion = `Colombia esta en America, y Bucaramanga que esta en el departamento de Santander tiene un barrio llamado el prado y sus 3000 personas hablan ingles`
    console.log(descripcion)
})()
console.groupEnd();
// ----------------------------------------------------------------------------------
// PUNTO 5
//Repita el ejercicio usando Template strings
console.group("Punto 5");
(()=>{
    const barrio = "San Francisco", poblacion = 15000, idioma = "Español";
    let descripcion = `Colombia esta en America, y Bucaramanga que esta en el departamento de Santander tiene un barrio llamado el ${barrio} y sus ${poblacion} personas hablan ${idioma}}`
    console.log(descripcion)
})()
console.groupEnd();
// ----------------------------------------------------------------------------------
//Metodos en cadenas
console.group("Metodos en cadenas");
/* Cree 10 variables de tipo cadena donde almacene valores string en
Ingles y aplique cada una de los siguientes métodos de cadena 
1. length
2. includes()
3. back ticks o templatre strings
4. trimStart()
5. trimEnd()
6. replace
7. slice
8. split
9. ToUpperCase
10. ToLowerCase
*/

const cadena1 = 'Hello World', cadena2 = 'Life is short, make the most of it.', cadena3 = 'Time heals all wounds.', 
    cadena4 = '   Actions speak louder than words.', cadena5 = 'Practice makes perfect.       ', cadena6 = 'You only live once.', 
    cadena7 = "Don't give up on your dreams.", cadena8 = "It's better to be safe than sorry.", 
    cadena9 = 'Honesty is the best policy.', cadena10 = 'LAUGHTER IS THE BEST MEDICINE.';
console.log(`Cadena1: ${cadena1} - Length: ${cadena1.length}`)
console.log(`Cadena2: ${cadena2} - Includes: ${cadena2.includes('a')}`)
console.log(`Cadena3: ${cadena3} - Back ticks: ${cadena3}`)
console.log(`Cadena4: ${cadena4} - TrimStart: ${cadena4.trimStart()}`)
console.log(`Cadena5: ${cadena5} - TrimEnd: ${cadena5.trimEnd()}`)
console.log(`Cadena6: ${cadena6} - Replace: ${cadena6.replace('once', 'twice')}`)
console.log(`Cadena7: ${cadena7} - Slice: ${cadena7.slice(0, 10)}`)
console.log(`Cadena8: ${cadena8} - Split: [${cadena8.split(' ')}]`)
console.log(`Cadena9: ${cadena9} - ToUpperCase: ${cadena9.toUpperCase()}`)
console.log(`Cadena10: ${cadena10} - ToLowerCase: ${cadena10.toLowerCase()}`)
console.groupEnd();
// ----------------------------------------------------------------------------------


